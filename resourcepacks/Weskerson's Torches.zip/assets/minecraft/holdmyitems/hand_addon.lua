local l = (bl and 1) or -1
local d = (bl and 1) or -0.43
local a = (bl and 1) or 0.8
global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

--torch
if (
    I:isOf(item, Items:get("minecraft:torch")) or
    I:isOf(item, Items:get("minecraft:soul_torch")) or
    I:isOf(item, Items:get("minecraft:redstone_torch"))
) 
then
    M:rotateZ(matrices, 10 * l)
    M:moveZ(matrices, 0.05)
end

--comp and rep
if (
    I:isOf(item, Items:get("minecraft:repeater")) or
    I:isOf(item, Items:get("minecraft:comparator")) 
)
    
then
    M:rotateZ(matrices, 10 * l)
    M:moveZ(matrices, 0.05)
    M:moveY(matrices, -0.09)
    M:moveX(matrices, -0.09 * l) 
end